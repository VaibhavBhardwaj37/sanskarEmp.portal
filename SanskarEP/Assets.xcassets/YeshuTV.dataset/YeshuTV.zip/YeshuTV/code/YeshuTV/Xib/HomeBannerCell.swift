//
//  HomeBannerCell.swift
//  YeshuTV
//
//  Created by virendra kumar on 17/12/21.
//

import UIKit
import FSPagerView

class HomeBannerCell: FSPagerViewCell {

    @IBOutlet weak var bannerImage:UIImageView!
  

}
