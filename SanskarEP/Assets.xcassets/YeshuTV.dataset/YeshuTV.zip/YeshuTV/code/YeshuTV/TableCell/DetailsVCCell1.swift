//
//  DetailsVCCell1.swift
//  YeshuTV
//
//  Created by virendra kumar on 24/12/21.
//

import UIKit
import ExpandableLabel

class DetailsVCCell1: UITableViewCell {

    @IBOutlet weak var videoTitle_Lbl:UILabel!
    @IBOutlet weak var favoriteBtn:UIButton!
    @IBOutlet weak var shareBtn:UIButton!
    @IBOutlet weak var desciptionLbl:ExpandableLabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
