//
//  HomeTableCellSubCategory.swift
//  YeshuTV
//
//  Created by virendra kumar on 23/12/21.
//

import UIKit

class HomeTableCellSubCategory: UITableViewCell {
    @IBOutlet weak var subMenuView:SubMenuView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
