//
//  DownloadVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 16/12/21.
//

import UIKit

class DownloadVC: UIViewController {
    @IBOutlet weak var myTableView:UITableView!
    @IBOutlet weak var profileImage:UIImageView!
    @IBOutlet weak var loginBtn:UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTableView.setBackgroundIfNoData(message: "Not Implemented")
    }
    override func viewWillAppear(_ animated: Bool) {
        if currentUser.id == "0"{
            loginBtn.setTitle("Login", for: .normal)
            profileImage.isHidden = true
        }else{
            profileImage.sd_setImage(with: URL(string: currentUser.profile_picture), placeholderImage: UIImage(named: "profile_default"), options: .refreshCached, context: nil)
            loginBtn.setTitle("", for: .normal)
            profileImage.isHidden = false
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
       
    }
    
    @IBAction func profileActionBtn(_ sender:UIButton){
        if currentUser.id == "0"{
            let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "LoginSignupVC") as! LoginSignupVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{

            
        }
    }
    
    
    @IBAction func searchActionBtn(_ sender:UIButton){
        let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }


}
