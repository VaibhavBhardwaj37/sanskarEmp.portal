//
//  ChangePasswordVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 29/12/21.
//

import UIKit

class ChangePasswordVC: UIViewController,DesignableTextFieldDelegate {

    
    @IBOutlet weak var passwordFiled1:DesignableTextField!
    @IBOutlet weak var passwordFiled2:DesignableTextField!
    
    var Otp = ""
    var Mobile = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passwordFiled1.delegate = self
        passwordFiled2.delegate = self
        
    }
    
    @IBAction func backActionBtn(_ sneder:UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func textFieldIconClicked(btn: UIButton) {
        if btn.tag == 1{
            if passwordFiled1.isSecureTextEntry {
                btn.setImage(UIImage(named: "show_pass"), for: .normal)
                passwordFiled1.isSecureTextEntry = false
            }else{
                btn.setImage(UIImage(named: "eye_off"), for: .normal)
                passwordFiled1.isSecureTextEntry = true
            }

        }else{
            if passwordFiled2.isSecureTextEntry {
                passwordFiled2.isSecureTextEntry = false
                btn.setImage(UIImage(named: "show_pass"), for: .normal)
            }else{
                btn.setImage(UIImage(named: "eye_off"), for: .normal)
                passwordFiled2.isSecureTextEntry = true
            }

        }
    }
    
    
    
    @IBAction func createPasswordActionBtn(_ sender:UIButton){
        if passwordFiled1.text!.replacingOccurrences(of: " ", with: "") == ""{
            AlertController.alert(message: "Please Enter Password")
        }
        else if passwordFiled2.text!.replacingOccurrences(of: " ", with: "") == ""{
            AlertController.alert(message: "Please Confirm Password")
        }
        else if passwordFiled1.text! != passwordFiled2.text!{
            AlertController.alert(message: "Both password not Mached")
        }
        else if passwordFiled1.text!.count < 8 || passwordFiled1.text!.count > 16{
            AlertController.alert(message: """
                Please enter minimum 8 charcter and maximum 16 for strong password \n
                At least 1 capital letter
                At least 1 lowercase letter
                At least 1 special character
                At least 1 numeric character
                """)
        }
        else{
            updatePasswordAPI()
        }
        
    }


    // MARK: Hit Register API after Otp verification done
    func updatePasswordAPI(){
        
        var dict = Dictionary<String,Any>()
        dict["otp"] = Otp
        dict["mobile"] = Mobile
        dict["password"] = passwordFiled1.text!
        
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kupdate_password_via_otp) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                self.navigationController?.popToViewController(ofClass: LoginSignupVC.self)
            }
        }
    }

    
}
