//
//  SearchVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 23/12/21.
//

import UIKit
import PIPKit
class SearchVC: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var text_field:UITextField!
    @IBOutlet weak var MyCollectionView:UICollectionView!
    
    var searchResultList:[ListingModel]?
    private var WorkItem: DispatchWorkItem?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        text_field.text = ""
        text_field.delegate = self
        MyCollectionView.dataSource = self
        MyCollectionView.delegate = self
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        UIView.animate(withDuration: 0.3) {
            self.text_field.becomeFirstResponder()
        }
    }
    
    @IBAction func backActionBtn(_ sender:UIButton){
        self.view.endEditing(true)
        self.navigationController?.popViewController(animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if  self.text_field.isEditing{
            self.view.endEditing(true)
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
        WorkItem?.cancel()
        if self.text_field.text! != ""{
            self.callToSearchData()
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        WorkItem?.cancel()
        if self.text_field.text! != ""{
            self.callToSearchData()
        }
        return true
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        WorkItem?.cancel()
        let requestWorkItem = DispatchWorkItem { [weak self] in
            if self?.text_field.text! != ""{
                self?.callToSearchData()
            }
        }
        
        WorkItem = requestWorkItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: requestWorkItem)
        
        return true
    }
    
    //MARK:- Get Dashboard with selected type Data like video,audio,pdf List API
    func callToSearchData() {
        var dict = Dictionary<String,Any>()
        dict["guru_id"] = "7"
        dict["user_id"] = currentUser.id
        dict["search_string"] = text_field.text
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Ksearch_list) { (status, responseDict, error, data) in
            Loader.hideLoader()
            self.view.endEditing(true)
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict!["data"] as Any
                if let nsdata = convertAnythingTOData(dict: dataArr) {
                    let jsonDecoder = JSONDecoder()
                    self.searchResultList = try? jsonDecoder.decode([ListingModel].self, from: nsdata)
                    self.MyCollectionView.reloadData()
                }
            }else{
                self.searchResultList = nil
            }
        }
    }
    
    
}



//MARK:- CollectionView DataSourse And Delegate
extension SearchVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return searchResultList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let img = cell.contentView.viewWithTag(11) as? UIImageView
        let lbl = cell.contentView.viewWithTag(12) as? UILabel
        let Timelbl = cell.contentView.viewWithTag(13) as? UILabel
        let logoBtn = cell.contentView.viewWithTag(14) as? UIButton
        
        cell.layer.shadowColor = UIColor.random().cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 3)
        cell.layer.shadowRadius = 3
        cell.layer.shadowOpacity = 0.3
        cell.layer.masksToBounds = false
        img?.layer.cornerRadius = 4.0
        
        Timelbl?.isHidden = true
        
        if searchResultList?[indexPath.row].typeID == "1"{
            Timelbl?.isHidden = false
            Timelbl?.text = searchResultList?[indexPath.row].timeingText
            logoBtn?.setImage(UIImage(named: "video"), for: .normal)
        }
        
        else if searchResultList?[indexPath.row].typeID == "2"{
             logoBtn?.setImage(UIImage(named: "audio"), for: .normal)
         }
        else if searchResultList?[indexPath.row].typeID == "3"{
             logoBtn?.setImage(UIImage(named: "pdf"), for: .normal)
         }
        
        
        let imgurl = searchResultList?[indexPath.row].bannerURL ?? ""
        lbl?.text = searchResultList?[indexPath.row].title ?? " "
        img?.sd_setImage(with: URL(string: imgurl), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: (collectionView.frame.size.width/2) - 15, height: (collectionView.frame.size.width/2)-15)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if searchResultList?[indexPath.row].typeID == "1"{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVCWithPlayer") as! DetailsVCWithPlayer
            vc.videoData = searchResultList?[indexPath.row]
            PIPKit.show(with: vc)
            vc.stopPIPMode()
        }else if searchResultList?[indexPath.row].typeID == "2"{
            print("Audio Selected")
        }else if searchResultList?[indexPath.row].typeID == "3"{
            print("PDF Selected")
        }else{
            print("Uknown Type Selected")
        }
  
    }
    
}
