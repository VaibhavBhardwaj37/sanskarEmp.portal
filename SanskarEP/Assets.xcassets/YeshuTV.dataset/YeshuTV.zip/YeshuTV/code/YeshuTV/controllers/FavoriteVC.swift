//
//  FavoriteVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 16/12/21.
//

import UIKit
import PIPKit

class FavoriteVC: UIViewController {
    
    @IBOutlet weak var MyCollectionView:UICollectionView!
    @IBOutlet weak var profileImage:UIImageView!
    @IBOutlet weak var loginBtn:UIButton!
    
    var favoriteResultList:[ListingModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MyCollectionView.setBackgroundIfNoData(message: "Loading...")
        MyCollectionView.delegate = self
        MyCollectionView.dataSource = self
    }
    

    
    @IBAction func profileActionBtn(_ sender:UIButton){
        if currentUser.id == "0"{
            let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "LoginSignupVC") as! LoginSignupVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{

        }
    }
    
    
    @IBAction func searchActionBtn(_ sender:UIButton){
        let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if currentUser.id == "0"{
            loginBtn.setTitle("Login", for: .normal)
            profileImage.isHidden = true
        }else{
            profileImage.sd_setImage(with: URL(string: currentUser.profile_picture), placeholderImage: UIImage(named: "profile_default"), options: .refreshCached, context: nil)
            loginBtn.setTitle("", for: .normal)
            profileImage.isHidden = false
        }
        callFuncToGetFavoriteData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
    }
}


//MARK:- CollectionView DataSourse And Delegate
extension FavoriteVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if favoriteResultList?.count ?? 0 != 0{
            MyCollectionView.setBackgroundIfNoData(message: "")
        }
        return favoriteResultList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        let img = cell.contentView.viewWithTag(11) as? UIImageView
        let lbl = cell.contentView.viewWithTag(12) as? UILabel
        let Timelbl = cell.contentView.viewWithTag(13) as? UILabel
        let logoBtn = cell.contentView.viewWithTag(14) as? UIButton
        
        
        cell.layer.shadowColor = UIColor.random().cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 3)
        cell.layer.shadowRadius = 3
        cell.layer.shadowOpacity = 0.3
        cell.layer.masksToBounds = false
        img?.layer.cornerRadius = 4.0
        
        Timelbl?.isHidden = true
        
        if favoriteResultList?[indexPath.row].typeID == "1"{
            Timelbl?.isHidden = false
            Timelbl?.text = favoriteResultList?[indexPath.row].timeingText
            logoBtn?.setImage(UIImage(named: "video"), for: .normal)
        }
        
        else if favoriteResultList?[indexPath.row].typeID == "2"{
             logoBtn?.setImage(UIImage(named: "audio"), for: .normal)
         }
        else if favoriteResultList?[indexPath.row].typeID == "3"{
             logoBtn?.setImage(UIImage(named: "pdf"), for: .normal)
         }
        
        let imgurl = favoriteResultList?[indexPath.row].bannerURL ?? ""
        lbl?.text = favoriteResultList?[indexPath.row].title ?? " "
        img?.sd_setImage(with: URL(string: imgurl), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: (collectionView.frame.size.width/2) - 15, height: (collectionView.frame.size.width/2)-15)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if favoriteResultList?[indexPath.row].typeID == "1"{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVCWithPlayer") as! DetailsVCWithPlayer
            vc.videoData = favoriteResultList?[indexPath.row]
            PIPKit.show(with: vc)
            vc.stopPIPMode()
        }else if favoriteResultList?[indexPath.row].typeID == "2"{
            print("Audio Selected")
        }else if favoriteResultList?[indexPath.row].typeID == "3"{
            print("PDF Selected")
        }else{
            print("Uknown Type Selected")
        }
        
    }
    
    
    //MARK:- Get Header Menu Data with MenuMaster API
    func callFuncToGetFavoriteData() {
        Loader.showLoader()
        var dict = Dictionary<String,Any>()
        dict["user_id"] = currentUser.id
        dict["guru_id"] = "7"
        
        APIManager.apiCall(postData: dict as NSDictionary, url: Kget_wishlist) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict?["data"] as Any
                if let nsdata = convertAnythingTOData(dict: dataArr) {
                    let jsonDecoder = JSONDecoder()
                    self.favoriteResultList = try? jsonDecoder.decode([ListingModel].self, from: nsdata)
                    self.MyCollectionView.reloadData()
                    
                }
            }else{
                self.MyCollectionView.setBackgroundIfNoData(message: "No Data Found")
                self.favoriteResultList = nil
            }
        }
    }
    
}
