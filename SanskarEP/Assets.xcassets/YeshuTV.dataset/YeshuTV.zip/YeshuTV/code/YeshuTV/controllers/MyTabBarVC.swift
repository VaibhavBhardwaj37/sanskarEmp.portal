//
//  MyTabBarVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 15/12/21.
//

import UIKit

class MyTabBarVC: UITabBarController {
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        print(self.selectedIndex)
    }
  
}

