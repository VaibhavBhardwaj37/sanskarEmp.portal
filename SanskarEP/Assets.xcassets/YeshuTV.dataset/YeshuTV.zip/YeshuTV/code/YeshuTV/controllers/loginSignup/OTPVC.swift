//
//  OTPVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 29/12/21.
//

import UIKit
enum comeFrom {
    case registration
    case forgotPassword
}

class OTPVC: UIViewController {
    
    @IBOutlet weak var OTPTextFiled:UITextField!
    @IBOutlet weak var resend_btn:UIButton!
    @IBOutlet weak var timerLable:UILabel!
    
    var comeFor : comeFrom = .registration
    var dict = Dictionary<String,Any>()
    
    var timer:Timer?
    var counter = 60
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resend_btn.isUserInteractionEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: { [weak self](time) in
            if self?.counter == 0{
                self?.counter = 60
                self?.timerLable.text = ""
                self?.resend_btn.isUserInteractionEnabled = true
                self?.timer?.invalidate()
            }else{
                self?.counter = self!.counter - 1
                self?.timerLable.text = "in : \(String(describing: self!.counter))"
            }
        })
        timer?.fire()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.timer?.invalidate()
    }
    
    @IBAction func backActionBtn(_ sneder:UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func verifyActionBtn(_ sneder:UIButton){
        if OTPTextFiled.text!.isNumeric(){
            VerifyAPI()
        }else{
            AlertController.alert(message: "Please enter OTP.")
        }
    }
    
    @IBAction func resendActionBtn(_ sneder:UIButton){
        ResendOtpAPI()
    }
    
    
    // MARK: ResendOtpAPI
    func ResendOtpAPI(){
        var dict = Dictionary<String,Any>()
        dict["mobile"] = self.dict.validatedValue("mobile")
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Ksend_verification_otp) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                self.resend_btn.isUserInteractionEnabled = false
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                self.viewWillAppear(true)
            }
        }
    }
    
    
    // MARK: Verify OTP With Same API using paramter OTP And Mobile number
    func VerifyAPI(){
        var dict = Dictionary<String,Any>()
        dict["mobile"] = self.dict.validatedValue("mobile")
        dict["otp"] = OTPTextFiled.text!
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Ksend_verification_otp) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                if self.comeFor == .forgotPassword{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
                    vc.Mobile = self.dict.validatedValue("mobile")
                    vc.Otp = self.OTPTextFiled.text!
                    self.navigationController?.pushViewController(vc, animated: true)
                }else{
                    self.registrationAPI()
                }
            }
        }
    }
    
    // MARK: Hit Register API after Otp verification done
    func registrationAPI(){
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kregistration) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
