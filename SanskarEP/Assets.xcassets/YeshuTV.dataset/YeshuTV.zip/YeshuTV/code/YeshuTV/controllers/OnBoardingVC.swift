//
//  OnBoardingVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 17/12/21.
//

import UIKit

class OnBoardingVC: UIViewController {

    @IBOutlet weak var pageControl:UIPageControl!
    var current = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        pageControl.numberOfPages = 5
        
       
    }

    @IBAction func NextActionBtn(_ sender:UIButton){

        if current == 4{
            currentUser.saveValue(value: "0", key: "id")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyTabBarVC") as! MyTabBarVC
            self.navigationController?.pushViewController(vc, animated: true)

        }else{
            current = current+1
            pageControl.currentPage = current
        }
        
    }
   
    @IBAction func skipActionBtn(_ sender:UIButton){

        currentUser.saveValue(value: "0", key: "id")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyTabBarVC") as! MyTabBarVC
        self.navigationController?.pushViewController(vc, animated: true)
    
    }
}

