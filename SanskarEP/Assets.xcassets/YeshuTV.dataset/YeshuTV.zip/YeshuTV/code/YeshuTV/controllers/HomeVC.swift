//
//  HomeVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 16/12/21.
//

import UIKit
import FSPagerView
import PIPKit
import AVKit

class HomeVC: UIViewController {
    
    @IBOutlet weak var bannerCollection:FSPagerView!{
        didSet {
            self.bannerCollection.register(UINib(nibName:"HomeBannerCell", bundle: Bundle.main), forCellWithReuseIdentifier: "HomeBannerCell")
            self.bannerCollection.itemSize = CGSize(width: bannerCollection.frame.size.width, height: bannerCollection.frame.size.height)
            bannerCollection.interitemSpacing = 4
            //bannerCollection.transformer = FSPagerViewTransformer(type: .linear)
        }
    }
    
    @IBOutlet weak var pageControl:UIPageControl!
    @IBOutlet weak var menuView:HomeMenuView!
    @IBOutlet weak var myTableView:UITableView!
    @IBOutlet weak var profileImage:UIImageView!
    @IBOutlet weak var loginBtn:UIButton!
    
    var ViewModel :DashboardViewModel?
    var selectedIndex = 0
    
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTableView.setBackgroundIfNoData(message: "Loading.....")
        self.myTableView.delegate = self
        self.myTableView.dataSource = self
        self.bannerCollection.isScrollEnabled = false
        pageControl.numberOfPages = 0
        bannerCollection.reloadData()
        getData()
        pullToRefresh()
        
    }
    //MARK:- PullToRefresh.
    func pullToRefresh() {
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector (refresh(sender:)), for: .valueChanged)
        myTableView.addSubview(refreshControl)
    }
    
    @objc func refresh(sender:AnyObject) {
        getData()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        if currentUser.id == "0"{
            loginBtn.setTitle("Login", for: .normal)
            profileImage.isHidden = true
        }else{
            profileImage.sd_setImage(with: URL(string: currentUser.profile_picture), placeholderImage: UIImage(named: "profile_default"), options: .refreshCached, context: nil)
            loginBtn.setTitle("", for: .normal)
            profileImage.isHidden = false
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        
    }
    
    @IBAction func profileActionBtn(_ sender:UIButton){
        if currentUser.id == "0"{
            let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "LoginSignupVC") as! LoginSignupVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            
        }
    }
    
    
    @IBAction func searchActionBtn(_ sender:UIButton){
        let vc = self.mainStoryBoard().instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    func getData(){
        selectedIndex = 0
        menuView.selectedIndex = IndexPath(row: 0, section: 0)
        ViewModel = DashboardViewModel()
        ViewModel?.bindMenuDataToController = { [weak self] in
            self?.menuView.menuList = self?.ViewModel?.menuList
        }
        
        ViewModel?.bindBannerDataToController = { [weak self] in
            self?.pageControl.numberOfPages = self?.ViewModel?.bannerList?.count ?? 0
            self?.bannerCollection.reloadData()
            if self?.ViewModel?.bannerList?.count ?? 0 == 0{
                self?.bannerCollection.isScrollEnabled = false
            }else{
                self?.bannerCollection.isScrollEnabled = true
            }
        }
        
        ViewModel?.bindContentListDataToController = { [weak self] in
            DispatchQueue.main.async(execute: { self?.refreshControl.endRefreshing()})
            self?.myTableView.setBackgroundIfNoData(message: "")
            self?.myTableView.reloadData()
        }
        
        menuView.simpleClosure = { [weak self] (index) in
            self?.selectedIndex = index
            if index == 0{
                self?.ViewModel?.callFuncToGetDashBoardData()
            }else{
                let typeId = self?.menuView?.menuList?[index].type_id ?? ""
                let Id     = self?.menuView?.menuList?[index].id ?? ""
                self?.ViewModel?.callFuncToGetDashBoardData(typeId: typeId, Id: Id)
            }
        }
    }
    
}

//MARK:-  Load video , audio , pdf, list with UITableViewDelegate,UITableViewDataSource

extension HomeVC :UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if selectedIndex == 0{
            return ViewModel?.contentList?.count ?? 0
        }else{
            if ViewModel?.contentList?.count ?? 0 == 0{
                return 0
            }else{
                return (ViewModel?.contentList?.count ?? 0)+1
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedIndex == 0{
            return ViewModel?.contentList?[section].listing?.count ?? 0
        }else{
            if section == 0{
                return 1
            }else{
                return  ViewModel?.contentList?[section-1].listing?.count ?? 0
            }
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if selectedIndex == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
            
            let img_view = cell?.contentView.viewWithTag(11) as? UIImageView
            let lbl = cell?.contentView.viewWithTag(12) as? UILabel
            let Timelbl = cell?.contentView.viewWithTag(13) as? UILabel
            let logoBtn = cell?.contentView.viewWithTag(14) as? UIButton
            
            let data = ViewModel?.contentList?[indexPath.section].listing?[indexPath.row]
            let banner = data?.bannerURL ?? ""
            Timelbl?.isHidden = true
            
            if data?.typeID == "1"{
                Timelbl?.isHidden = false
                Timelbl?.text = data?.timeingText
                logoBtn?.setImage(UIImage(named: "video"), for: .normal)
            }
            
            else if data?.typeID == "2"{
                logoBtn?.setImage(UIImage(named: "audio"), for: .normal)
            }
            else if data?.typeID == "3"{
                logoBtn?.setImage(UIImage(named: "pdf"), for: .normal)
            }
            
            lbl?.text = data?.title
            img_view?.sd_setImage(with: URL(string: banner), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
            
            return cell ?? UITableViewCell()
        }else{
            if indexPath.section == 0{
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableCellSubCategory") as! HomeTableCellSubCategory
                cell.subMenuView.subMenuList = self.ViewModel?.subMenuList
                return cell 
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
                let img_view = cell?.contentView.viewWithTag(11) as? UIImageView
                let lbl = cell?.contentView.viewWithTag(12) as? UILabel
                let Timelbl = cell?.contentView.viewWithTag(13) as? UILabel
                let logoBtn = cell?.contentView.viewWithTag(14) as? UIButton
                let data = ViewModel?.contentList?[indexPath.section-1].listing?[indexPath.row]
                
                Timelbl?.isHidden = true
                
                if data?.typeID == "1"{
                    Timelbl?.isHidden = false
                    Timelbl?.text = data?.timeingText
                    logoBtn?.setImage(UIImage(named: "video"), for: .normal)
                }
                else if data?.typeID == "2"{
                    logoBtn?.setImage(UIImage(named: "audio"), for: .normal)
                }
                else if data?.typeID == "3"{
                    logoBtn?.setImage(UIImage(named: "pdf"), for: .normal)
                }
                
                
                let banner = data?.bannerURL ?? ""
                lbl?.text = data?.title
                img_view?.sd_setImage(with: URL(string: banner), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
                return cell ?? UITableViewCell()
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if selectedIndex == 0{
            let data = ViewModel?.contentList?[indexPath.section]
            let content = data?.listing?[indexPath.row]
            if content?.typeID == "1"{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVCWithPlayer") as! DetailsVCWithPlayer
                vc.videoData = content
                vc.mainID = data?.id ?? data?.catID ?? ""
                PIPKit.show(with: vc)
                vc.stopPIPMode()
            }
            else if content?.typeID == "2"{
                print("Audio selected")
            }
            else if content?.typeID == "3"{
                print("PDF selected")
            }else{
                print("Uknown Type Selected")
            }
            
        }else{
            if indexPath.section != 0{
                let data = ViewModel?.contentList?[indexPath.section-1]
                let content = data?.listing?[indexPath.row]
                if content?.typeID  == "1"{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVCWithPlayer") as! DetailsVCWithPlayer
                    vc.videoData = content
                    vc.mainID = data?.id ?? data?.catID ?? ""
                    PIPKit.show(with: vc)
                    vc.stopPIPMode()
                }
                else if content?.typeID == "2"{
                    print("Audio selected")
                }
                else if content?.typeID == "3"{
                    print("PDF selected")
                }else{
                    print("Uknown Type Selected")
                }
            }
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}



//MARK:- Banner Load with FSPagerViewDataSource,FSPagerViewDelegate

extension HomeVC:FSPagerViewDataSource,FSPagerViewDelegate{
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return self.ViewModel?.bannerList?.count ?? 0
    }
    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "HomeBannerCell", at: index) as! HomeBannerCell
        cell.layer.shadowColor = UIColor.random().cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 3)
        cell.layer.shadowRadius = 3
        cell.layer.shadowOpacity = 0.3
        cell.layer.masksToBounds = true
        cell.layer.cornerRadius = 5
        let banner = self.ViewModel?.bannerList?[index].imageURL ?? ""
        cell.imageView?.sd_setImage(with: URL(string: banner), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
        return cell
    }
    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        pagerView.deselectItem(at: index, animated: true)
        pagerView.scrollToItem(at: index, animated: true)
    }
    func pagerViewWillEndDragging(_ pagerView: FSPagerView, targetIndex: Int) {
        self.pageControl.currentPage = targetIndex
    }
    func pagerViewDidEndScrollAnimation(_ pagerView: FSPagerView) {
        self.pageControl.currentPage = pagerView.currentIndex
    }
    
}
