//
//  DetailsVCWithPlayer.swift
//  YeshuTV
//
//  Created by virendra kumar on 23/12/21.
//

import UIKit
import PIPKit
import AVKit
import ExpandableLabel

class DetailsVCWithPlayer: UIViewController,PIPUsable {
    
    @IBOutlet weak var playerView:UIView!
    @IBOutlet weak var playBackControlView:UIView!
    @IBOutlet weak var videoTitle_lbl:UILabel!
    @IBOutlet weak var bottomCons:NSLayoutConstraint!
    @IBOutlet weak var myTaleView:UITableView!
    @IBOutlet weak var playPuseBtn:UIButton!
    @IBOutlet weak var playPuseBtn2:UIButton!
    @IBOutlet weak var slider:UISlider!
    @IBOutlet weak var time_Label:UILabel!
    @IBOutlet weak var loaderView:UIActivityIndicatorView!
    @IBOutlet weak var playerContainerView:UIView!
    
    var videoData : ListingModel?
    private var WorkItem: DispatchWorkItem?
    var numberOfLine = 3
    var mainID = ""
    
    deinit {
        print("DetailsVCWithPlayer Deallocated from Memory")
    }
    
    var details:DetailsViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        details = DetailsViewModel()
        details?.callFuncToGetDetailPageData(TypeID:videoData?.typeID ?? "",Id:videoData?.id ?? "")
        details?.bindDetailsToController = { [weak self] in
            self?.myTaleView.reloadData()
        }
        
        videoTitle_lbl.text = self.videoData?.title ?? ""
        myTaleView.dataSource = self
        myTaleView.delegate = self
        DispatchQueue.main.async {
            let CVC = self.children.first as! AVPlayerVC
            CVC.playPauseBtn = self.playPuseBtn
            CVC.playPauseBtn2 = self.playPuseBtn2
            CVC.time_Lbl = self.time_Label
            CVC.slider  = self.slider
            CVC.loader = self.loaderView
            CVC.PlayeUrl(url : self.videoData?.url ?? "",Video_title:"")
        }
        let TapGesture = UITapGestureRecognizer.init(target: self, action: #selector(didTap))
        let TapGesture2 = UITapGestureRecognizer.init(target: self, action: #selector(didTap))
        self.playBackControlView.addGestureRecognizer(TapGesture2)
        self.playerContainerView.addGestureRecognizer(TapGesture)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.coverViewHide()
        }
        setSliderThumbTintColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
    
    
    func setSliderThumbTintColor(_ color: UIColor) {
        let circleImage = makeCircleWith(size: CGSize(width: 15, height: 15),backgroundColor: color)
        slider.setThumbImage(circleImage, for: .normal)
        slider.setThumbImage(circleImage, for: .highlighted)
    }
    
    fileprivate func makeCircleWith(size: CGSize, backgroundColor: UIColor) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        let context = UIGraphicsGetCurrentContext()
        context?.setFillColor(backgroundColor.cgColor)
        context?.setStrokeColor(UIColor.clear.cgColor)
        let bounds = CGRect(origin: .zero, size: size)
        context?.addEllipse(in: bounds)
        context?.drawPath(using: .fill)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    //MARK:- Tap to show or hide Bottom and top view
    @objc private func didTap(_ sender:UITapGestureRecognizer){
        if sender.view == playerContainerView{
            if PIPKit.isPIP {
                stopPIPMode()
            }
        }
        WorkItem?.cancel()
        let requestWorkItem = DispatchWorkItem { [weak self] in
            self?.coverViewHide()
        }
        WorkItem = requestWorkItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: requestWorkItem)
        showHideCoverView()
        
    }
    //MARK:- showHideCoverView()
    private func showHideCoverView(){
        DispatchQueue.main.async {
            UIView.animate(withDuration: 0.3) {
                if self.playBackControlView.isHidden{
                    self.playBackControlView.isHidden = false
                }else{
                    self.playBackControlView.isHidden = true
                }
            }
        }
    }
    
    //MARK:- coverViewHide()
    private func coverViewHide(){
        DispatchQueue.main.async {
            UIView.animate(withDuration: 0.3) {
                self.playBackControlView.isHidden = true
            }
        }
    }
    
    @IBAction func backAction(_ sender:UIButton){
        let CVC = self.children.first as! AVPlayerVC
        CVC.player = nil
        CVC.playerItemStatusObservation = nil
        CVC.currentItemErrorObservation = nil
        UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
        self.view.insetsLayoutMarginsFromSafeArea = true
        PIPKit.dismiss(animated: true)
    }
    
    @IBAction func rightEllipsAction(_ sender:UIButton){
        print("ajkhsdkjashdkjahsfsa")
    }
    
    @IBAction func LandscapTapAction(_ sender:UIButton){
        let CVC = self.children.first as! AVPlayerVC
        CVC.setOrientation()
        if UIDevice.current.orientation.rawValue == 1{
            sender.setImage(UIImage(named: "switchToFullScreen"), for: .normal)
            bottomCons.constant = 3.0
        }else{
            sender.setImage(UIImage(named: "full-screen-exit"), for: .normal)
            bottomCons.constant = 20.0
        }
        self.view.layoutIfNeeded()
    }
    
    @IBAction func PIPTapAction(_ sender:UIButton){
        if PIPKit.isPIP {
            playBackControlView.isHidden = false
            stopPIPMode()
        } else {
            bottomCons.constant = 3.0
            playBackControlView.isHidden = true
            UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
            self.view.insetsLayoutMarginsFromSafeArea = true
            startPIPMode()
        }
        self.view.layoutIfNeeded()
    }
    
    @IBAction func PlayPauseTapAction(_ sender:UIButton){
        let CVC = self.children.first as! AVPlayerVC
        CVC.playPause()
    }
    @IBAction func forwardTapAction(_ sender:UIButton){
        let CVC = self.children.first as! AVPlayerVC
        CVC.forward15Second()
    }
    @IBAction func backwardTapAction(_ sender:UIButton){
        let CVC = self.children.first as! AVPlayerVC
        CVC.backward15Second()
    }
    
    @IBAction func sliderSlideAction(_ sender:UISlider){
        let CVC = self.children.first as! AVPlayerVC
        CVC.sliderValueChange(slider: sender)
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        if touches.first?.view == self.playerView{
            print("ksfksjhdfkjsdhfkjsdf")
        }
        if PIPKit.isPIP {
            playBackControlView.isHidden = false
            stopPIPMode()
        }
    }
    
    
    func didChangedState(_ state: PIPState) {
        switch state {
        case .pip:
            print("PIPViewController.pip")
        case .full:
            print("PIPViewController.full")
        }
    }
}

extension DetailsVCWithPlayer:UITableViewDataSource,UITableViewDelegate,ExpandableLabelDelegate{
    func willCollapseLabel(_ label: ExpandableLabel) {
        print("willCollapseLabel")
    }
    
    func didCollapseLabel(_ label: ExpandableLabel) {
        print("didCollapseLabel")
    }
    
    func willExpandLabel(_ label: ExpandableLabel) {
        if label.numberOfLines == 3{
            label.numberOfLines = 0
        }else{
            label.numberOfLines = 3
        }
    }
    func didExpandLabel(_ label: ExpandableLabel) {
        myTaleView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return 1
        }else{
            return details?.dataList?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0{
            return nil
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "headerCell")
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsVCCell1") as! DetailsVCCell1
            
            
            cell.desciptionLbl.text = videoData?.listingDescription?.htmlToString
            cell.desciptionLbl.collapsedAttributedLink = NSAttributedString(string: "Read More")
            cell.desciptionLbl.expandedAttributedLink = NSAttributedString(string: "Read Less")
            cell.desciptionLbl.setLessLinkWith(lessLink: "Close", attributes: [NSAttributedString.Key.foregroundColor:UIColor.red], position: nil)
            cell.desciptionLbl.ellipsis = NSAttributedString(string: "...")
            cell.desciptionLbl.delegate = self
            
            if details?.isBookMarked == "1"{
                cell.favoriteBtn.tintColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
            }else{
                cell.favoriteBtn.tintColor = .lightGray
            }
            
            cell.videoTitle_Lbl.text = videoData?.title
            cell.favoriteBtn.tag = indexPath.row
            cell.shareBtn.tag = indexPath.row
            cell.shareBtn.addTarget(self, action: #selector(shareAction), for: .touchUpInside)
            cell.favoriteBtn.addTarget(self, action: #selector(favoriteAction), for: .touchUpInside)
            
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell2")
            
            
            cell?.layer.shadowColor = UIColor.random().cgColor
            cell?.layer.shadowOffset = CGSize(width: 0, height: 3)
            cell?.layer.shadowRadius = 3
            cell?.layer.shadowOpacity = 0.3
            cell?.layer.masksToBounds = false
            
            let img_view = cell?.contentView.viewWithTag(11) as? UIImageView
            img_view?.layer.cornerRadius = 4.0
            
            let lbl = cell?.contentView.viewWithTag(12) as? UILabel
            let Timelbl = cell?.contentView.viewWithTag(13) as? UILabel
            let data = details?.dataList?[indexPath.row]
            
            Timelbl?.isHidden = true
            if data?.typeID == "1"{
                Timelbl?.isHidden = false
                Timelbl?.text = data?.timeingText
            }

            let banner = data?.bannerURL ?? ""
            lbl?.text = data?.title
            img_view?.sd_setImage(with: URL(string: banner), placeholderImage: UIImage(named: "landscape_placeholder"), options: .refreshCached, context: nil)
            return cell ?? UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section != 0{
            self.videoData = details?.dataList?[indexPath.row]
            videoTitle_lbl.text = self.videoData?.title ?? "".htmlToString
            let CVC = self.children.first as! AVPlayerVC
            CVC.PlayeUrl(url : self.videoData?.url ?? "",Video_title:"")
            myTaleView.reloadData()
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0{
            return .leastNormalMagnitude
        }else{
            return 50
        }
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNormalMagnitude
    }
    
    @objc func shareAction(_ sender:UIButton){
        
    }
    
    @objc func favoriteAction(_ sender:UIButton){
        details?.callFuncToAddToFaveroite(TypeID:videoData?.typeID ?? "",Id:videoData?.id ?? "",mainID:mainID)
    }
}



