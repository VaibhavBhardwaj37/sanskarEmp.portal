//
//  LoginSignupVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 28/12/21.
//

import UIKit
import CountryPickerView

class LoginSignupVC: UIViewController {
    
    
    @IBOutlet weak var signinSegBtn:UIButton!
    @IBOutlet weak var signupSegBtn:UIButton!
    
    @IBOutlet weak var loginBtn:UIButton!
    @IBOutlet weak var ContinueBtn:UIButton!
    @IBOutlet weak var forgotBtn:UIButton!
    
    @IBOutlet weak var countryPicker:CountryPickerView!
    @IBOutlet weak var countryPickerHolderView:UIView!
    @IBOutlet weak var nameTextField:UITextField!
    @IBOutlet weak var mobileTextField:UITextField!
    @IBOutlet weak var emailTextField:UITextField!
    
    @IBOutlet weak var mobileLoginTextField:UITextField!
    @IBOutlet weak var passwordTextField:DesignableTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        passwordTextField.delegate = self
        countryPicker.delegate = self
        countryPicker.showPhoneCodeInView = true
        countryPicker.hostViewController = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        passwordTextField.text = ""
        countryPickerHolderView.isHidden = true
        nameTextField.isHidden = true
        emailTextField.isHidden = true
        ContinueBtn.isHidden = true
        
        mobileLoginTextField.isHidden = false
        loginBtn.isHidden = false
        forgotBtn.isHidden = false
        
        signinSegBtn.setTitleColor(.black, for: .normal)
        signinSegBtn.backgroundColor = .white
        signupSegBtn.setTitleColor(.darkGray, for: .normal)
        signupSegBtn.backgroundColor = .lightGray
    }
    
    
    @IBAction func signInSegAction(_ sender:UIButton){
        
        countryPickerHolderView.isHidden = true
        nameTextField.isHidden = true
        emailTextField.isHidden = true
        ContinueBtn.isHidden = true
        
        mobileLoginTextField.isHidden = false
        loginBtn.isHidden = false
        forgotBtn.isHidden = false
        
        sender.setTitleColor(.black, for: .normal)
        sender.backgroundColor = .white
        
        signupSegBtn.setTitleColor(.darkGray, for: .normal)
        signupSegBtn.backgroundColor = .lightGray
        
    }
    @IBAction func signUpSegAction(_ sender:UIButton){
        mobileLoginTextField.isHidden = true
        loginBtn.isHidden = true
        forgotBtn.isHidden = true
        
        countryPickerHolderView.isHidden = false
        nameTextField.isHidden = false
        emailTextField.isHidden = false
        ContinueBtn.isHidden = false
        
        sender.setTitleColor(.black, for: .normal)
        sender.backgroundColor = .white
        
        signinSegBtn.setTitleColor(.darkGray, for: .normal)
        signinSegBtn.backgroundColor = .lightGray
        
    }
    
    @IBAction func forgotPasswordAction(_ sender:UIButton){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func loginAction(_ sender:UIButton){
        if mobileLoginTextField.text! == ""{
            AlertController.alert(message: "Please enter Mobile number.")
        }
        if mobileLoginTextField.text!.isNumeric() == false{
            AlertController.alert(message: "Please enter valid Mobile number.")
        }
        if passwordTextField.text! == ""{
            AlertController.alert(message: "Please enter Password.")
        }else{
            loginAPI()
        }
    }
    @IBAction func continueAction(_ sender:UIButton){
        if nameTextField.text! == ""{
            AlertController.alert(message: "Please enter Name.")
        }
        else if mobileTextField.text! == ""{
            AlertController.alert(message: "Please enter Mobile number.")
        }
        else if emailTextField.text! == ""{
            AlertController.alert(message: "Please enter Email ID.")
        }
        else if emailTextField.text!.ValidateEmail() == false{
            AlertController.alert(message: "Please enter valid Email ID.")
        }
        else if passwordTextField.text! == ""{
            AlertController.alert(message: "Please enter Password.")
        }
        else if passwordTextField.text!.count < 8 || passwordTextField.text!.count > 16{
            AlertController.alert(message: """
                Please enter minimum 8 charcter and maximum 16 for strong password \n
                At least 1 capital letter
                At least 1 lowercase letter
                At least 1 special character
                At least 1 numeric character
                """)
        }
        else{
            SignupAPI()
        }
    }
    
}

extension LoginSignupVC:DesignableTextFieldDelegate,CountryPickerViewDelegate{
    
    func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
        print(countryPicker.selectedCountry.phoneCode)
    }
    
    func textFieldIconClicked(btn: UIButton) {
        if passwordTextField.isSecureTextEntry {
            passwordTextField.isSecureTextEntry = false
            btn.setImage(UIImage(named: "show_pass"), for: .normal)
        }else{
            btn.setImage(UIImage(named: "eye_off"), for: .normal)
            passwordTextField.isSecureTextEntry = true
        }
    }
}



extension LoginSignupVC{
    
    // MARK:Login Normal
    func loginAPI(){
        var dict = Dictionary<String,Any>()
        dict["mobile"] = mobileLoginTextField.text!
        dict["password"] = passwordTextField.text!
        dict["device_id"] = currentUser.DeviceId
        dict["device_type"] = currentUser.device_type
        dict["device_token"] = currentUser.DeviceToken
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Klogin_authentication) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                currentUser.saveData(Login_Data: responseDict!)
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    
    // MARK: Signup
    func SignupAPI(){
        var dict = Dictionary<String,Any>()
        dict["country_code"] = countryPicker.selectedCountry.phoneCode
        dict["device_token"] = currentUser.DeviceToken
        dict["mobile"]       = mobileTextField.text!
        dict["device_type"]  = currentUser.device_type
        dict["name"]         = nameTextField.text!
        dict["device_id"]    = currentUser.DeviceId
        dict["device_model"] = currentUser.deviceModel
        dict["is_social"]    = "0"
        dict["password"]     = passwordTextField.text!
        
        Loader.showLoader()
        APIManager.apiCall(postData: ["mobile":mobileTextField.text!], url: Ksend_verification_otp) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "OTPVC") as! OTPVC
                vc.comeFor = .registration
                vc.dict = dict
                self.navigationController?.pushViewController(vc, animated: true)
                
            }
        }
    }
    
}
