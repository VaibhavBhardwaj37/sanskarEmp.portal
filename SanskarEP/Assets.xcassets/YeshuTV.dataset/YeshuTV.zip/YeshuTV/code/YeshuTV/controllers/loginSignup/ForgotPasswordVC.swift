//
//  ForgotPasswordVC.swift
//  YeshuTV
//
//  Created by virendra kumar on 29/12/21.
//

import UIKit

class ForgotPasswordVC: UIViewController {

    @IBOutlet weak var mobileTextFiled:UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func backActionBtn(_ sneder:UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func sendActionBtn(_ sneder:UIButton){
        if mobileTextFiled.text!.isNumeric() && mobileTextFiled.text!.count > 8{
            forgotPasswordAPI()
        }else{
            AlertController.alert(message: "Please enter you valid register mobile number")
        }
    }
    
    
    // MARK: forgot Password
    func forgotPasswordAPI(){
        var dict = Dictionary<String,Any>()
        dict["mobile"]       = mobileTextFiled.text!
        Loader.showLoader()
        APIManager.apiCall(postData: ["mobile":mobileTextFiled.text!], url: Ksend_verification_otp) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                AlertController.alert(message: responseDict?.validatedValue("message") ?? "")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "OTPVC") as! OTPVC
                vc.comeFor = .forgotPassword
                vc.dict = dict
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
}
