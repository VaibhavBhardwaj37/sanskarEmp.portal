//
//  AVPlayerVC.swift
//  ProceumPlayer
//
//  Created by virendra kumar on 20/08/21.
//

import UIKit
import AVFoundation
import AVKit

class AVPlayerVC: AVPlayerViewController{
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var playPauseBtn = UIButton()
    var slider = UISlider()
    var playPauseBtn2 = UIButton()
    var time_Lbl = UILabel()
    var loader = UIActivityIndicatorView()
    
    private var currentTime = CMTime()
    private var isUpdateTime = false
    var playerItemStatusObservation: NSKeyValueObservation?
    var currentItemErrorObservation: NSKeyValueObservation?
    @objc dynamic var pendingPlayerItem: AVPlayerItem?
    var totalTime = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loader.startAnimating()
        UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
        self.allowsPictureInPicturePlayback = true
        self.videoGravity = .resizeAspectFill
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.player = nil
        self.playerItemStatusObservation = nil
        self.currentItemErrorObservation = nil
        UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
        self.view.insetsLayoutMarginsFromSafeArea = true
    }
    
    deinit {
        print("AVPlayerVC Deallocated from Memory")
    }
    
    override var shouldAutorotate: Bool{
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    func setOrientation(){
        if UIDevice.current.orientation.rawValue == 1{
            UIDevice.current.setValue(UIInterfaceOrientation.landscapeLeft.rawValue, forKey: "orientation")
            self.view.insetsLayoutMarginsFromSafeArea = false
        }else{
            UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
            self.view.insetsLayoutMarginsFromSafeArea = true
        }
        self.videoGravity = .resizeAspectFill
        
    }
    
    func PlayeUrl(url : String,Video_title:String){
        DispatchQueue.main.async {
            self.player?.pause()
            let videoURL = URL(string: url)
            self.player = AVPlayer(url: videoURL!)
            let item = AVPlayerItem(url: videoURL!)
            self.player?.replaceCurrentItem(with: item)
            self.player?.play()
            self.pendingPlayerItem = item
            
            let timeScale = CMTimeScale(NSEC_PER_SEC)
            let timem = CMTime(seconds: 0.5, preferredTimescale: timeScale)
            self.player?.addPeriodicTimeObserver(forInterval: timem, queue: .main, using: { [weak self] (time) in
                self?.timerObserver(time: time)
            })
        }
        ObserveItemStatus()
    }
    
    
    func forward15Second(){
        let currentTime = self.player?.currentTime()
        let time =  CMTimeMake(value: Int64(10), timescale: 1)
        let forwardTime = time+currentTime!
        self.player?.seek(to: forwardTime, completionHandler: { [unowned self] (finish) in
            
        })
        self.player?.play()
    }
    func backward15Second(){
        let currentTime = self.player?.currentTime()
        let time =  CMTimeMake(value: Int64(10), timescale: 1)
        let backward = currentTime!-time
        self.player?.seek(to: backward, completionHandler: { [unowned self] (finish) in
            
        })
        self.player?.play()
    }
    
    func sliderValueChange(slider: UISlider) {
        self.player?.pause()
        self.isUpdateTime = true
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(delaySeekTime), object: nil)
        self.perform(#selector(delaySeekTime), with: nil, afterDelay: 0.1)
        let time =  CMTimeMake(value: Int64(self.slider.value), timescale: 1)
        timerObserver(time: time)
    }
    
    @objc func delaySeekTime() {
        let time =  CMTimeMake(value: Int64(self.slider.value), timescale: 1)
        self.player?.seek(to: time, completionHandler: { [unowned self] (finish) in
            self.isUpdateTime = false
            self.playPauseBtn.setImage(UIImage(named: "pauseCircle"), for: .normal)
            self.playPauseBtn2.setImage(UIImage(named: "pause_Fill"), for: .normal)
        })
        self.player?.play()
    }
    
    func playPause(){
        if self.player?.timeControlStatus == .playing{
            self.player?.pause()
            playPauseBtn.setImage(UIImage(named: "playCircle"), for: .normal)
            playPauseBtn2.setImage(UIImage(named: "play_Fill"), for: .normal)
        }else{
            playPauseBtn.setImage(UIImage(named: "pauseCircle"), for: .normal)
            playPauseBtn2.setImage(UIImage(named: "pause_Fill"), for: .normal)
            self.player?.play()
        }
    }
    
    private func ObserveItemStatus() {
        
        playerItemStatusObservation = observe(\.pendingPlayerItem?.status) { (object, change) in
            DispatchQueue.main.async { // Avoid modifying an observed property from directly within an observer.
                let pendingItemStatus = object.pendingPlayerItem?.status
                if pendingItemStatus == AVPlayerItem.Status.readyToPlay {
                    object.pendingPlayerItem = nil
                    //object.thumbnail_image.isHidden = true
                    self.loader.stopAnimating()
                    self.player?.play()
                    self.player?.rate = 1.0
                }
            }
        }
        currentItemErrorObservation = observe(\.self.player?.currentItem?.error) { (object, change) in
            DispatchQueue.main.async {
                if object.self.player?.currentItem?.error != nil {
                    // A very simple error handler: Just dismiss the playback UI.
                    // This is probably sufficient for unanticipated failures, or any where the error message is unlikely to help the user solve the problem.
                }else{
                    
                }
            }
        }
    }
    

    private func timerObserver(time: CMTime) {
        currentTime = time
        if let duration = self.player?.currentItem?.asset.duration ,
           !duration.isIndefinite ,
           !isUpdateTime {
            if self.slider.maximumValue != Float(duration.seconds) {
                self.slider.maximumValue = Float(duration.seconds)
            }
            totalTime = self.convert(second: duration.seconds)
            self.time_Lbl.text = self.convert(second: time.seconds) + "/" + totalTime
            self.slider.value = Float(time.seconds)
            
            if let range = self.player?.currentItem?.loadedTimeRanges.first {
                let tt =  CMTimeRangeGetEnd(range.timeRangeValue)
                let k =  (Float(duration.seconds) - Float(tt.seconds)) * 100 / Float(duration.seconds)
                let progress = (100 - k) / 100
                // progressBarBuffer.progress = progress
            }
            
        }else{
            if slider.maximumValue <= Float(time.seconds){
                slider.value = Float(time.seconds)
            }
            self.time_Lbl.text = self.convert(second: time.seconds) + "/" + totalTime
            
        }
    }
    
    
    private func convert(second: Double) -> String {
        let component =  Date.dateComponentFrom(second: second)
        if let hour = component.hour ,
           let min = component.minute ,
           let sec = component.second {
            let fix =  hour > 0 ? NSString(format: "%02d:", hour) : ""
            return NSString(format: "%@%02d:%02d", fix,min,sec) as String
        } else {
            return "-:-"
        }
    }
    
}
