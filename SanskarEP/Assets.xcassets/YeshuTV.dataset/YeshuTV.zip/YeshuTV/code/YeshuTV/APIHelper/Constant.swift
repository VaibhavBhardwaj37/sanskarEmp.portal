//
//  Constant.swift
//  Make My Exam
//
//  Created by Pintu on 5/5/18.
//  Copyright © 2017 Appsquadz. All rights reserved.


import Foundation
import Alamofire
import CoreLocation

let testUserID : String = "400"
let appName : String = "Yeshu TV"
let appSheetTitle: String = "Choose an option"
let customURLScheme : String = ""
let customURLSchemeCourse : String = ""
var kcountry_code = "+91"


let DYNAMIC_LINK_DOMAIN : String = ""
let storyBoard = UIStoryboard(name: "Main", bundle: nil)
var request: Alamofire.Request?

var appFeedLastContentOffset: CGFloat = 0
var appDDLastContentOffset: CGFloat = 0
var appStudyLastContentOffset: CGFloat = 0
var appExamLastContentOffset: CGFloat = 0
var appProfileLastContentOffset: CGFloat = 0

var locationmanager = CLLocationManager()
var userLatitude:CLLocationDegrees! = 0
var userLongitude:CLLocationDegrees! = 0

let accessKey = ".APSouth1"
let secretKey = "ap-south-1:2edec621-ef72-46a9-9489-2291d6860a64"

let screenSize: CGRect = UIScreen.main.bounds
let screenWidth  = screenSize.width
let screenHeight = screenSize.height



let appColor1 =  UIColor(named: "appColor1")
let appColorGrey =  UIColor(named: "appColorGrey")
let appColorYellowLight = UIColor(named: "appColorYellowLight")




let kDeviceType = "2"//for IOS
let kCureencySymbol = "₹"


let iPhone_5: Bool = (screenWidth == 320) && (screenHeight == 568) ? true : false
let iPhone_6: Bool = (screenWidth == 375) && (screenHeight == 667) ? true : false
let iPhone_7: Bool = (screenWidth == 414) && (screenHeight == 736) ? true : false
let iPhone_10: Bool = (screenWidth == 375) && (screenHeight == 812) ? true : false

