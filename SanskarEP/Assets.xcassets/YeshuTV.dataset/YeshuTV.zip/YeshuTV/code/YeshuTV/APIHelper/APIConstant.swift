//
//  APIConstant.swift
//  YeshuTV
//
//  Created by virendra kumar on 16/12/21.
//

import Foundation

var BASEURL = "http://13.126.100.113/index.php"

let Kregistration          = "data_model/user/registration/"
let Klogin_authentication  = "data_model/user/registration/login_authentication"
let Ksend_verification_otp = "data_model/user/registration/send_verification_otp"

let Kresend_verification_otp = "data_model/user/registration/resend_verification_otp" //Not in use sms getway not implemented in backend
let Kupdate_password_via_otp = "data_model/user/registration/update_password_via_otp"

let Ksubmit_query          = "data_model/dashboard/User_queries/submit_query"
let Kget_menu_master       = "data_model/Menu_master/get_menu_master"
let Kget_menu_sub_category = "data_model/Menu_master/get_menu_sub_category"
let Kbanner_list           = "data_model/dashboard/dashboard/banner_list"
let Kget_mobile_dashboard  = "data_model/dashboard/dashboard/get_mobile_dashboard"
let Ksearch_list           = "data_model/dashboard/dashboard/search_list"
let Kget_detail_page       = "data_model/dashboard/dashboard/get_detail_page"
let Kadd_to_wishlist       = "data_model/dashboard/dashboard/add_to_wishlist"
let Kget_wishlist          = "data_model/dashboard/dashboard/get_wishlist"




