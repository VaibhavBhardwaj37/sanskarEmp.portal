//
//  DetailsViewModel.swift
//  YeshuTV
//
//  Created by virendra kumar on 24/12/21.
//

import Foundation
class DetailsViewModel:NSObject{
    
    
    deinit {
        print("DashboardViewModel Dealloacated from Memory")
    }
    
    var dataList : [ListingModel]?{
        didSet {
            self.bindDetailsToController()
        }
    }
   
    var bindDetailsToController : (() -> ()) = {}
    var isBookMarked = ""
    
    override init() {
        super.init()
        
    }
    
    
    //MARK:- Get Header Menu Data with MenuMaster API
    func callFuncToGetDetailPageData(TypeID:String,Id:String) {
        Loader.showLoader()
        var dict = Dictionary<String,Any>()
        
        dict["user_id"] = currentUser.id
        dict["type_id"] = TypeID
        dict["id"]      = Id
        dict["guru_id"] = "7"
        APIManager.apiCall(postData: dict as NSDictionary, url: Kget_detail_page) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict?.dictValue("data")
                let releted = dataArr?["releted"] as Any
                self.isBookMarked = dataArr?.validatedValue("is_bookmarked") ?? ""
                if let nsdata = convertAnythingTOData(dict: releted) {
                    let jsonDecoder = JSONDecoder()
                    self.dataList = try? jsonDecoder.decode([ListingModel].self, from: nsdata)
                }
            }else{
                self.dataList = nil
            }
        }
    }
    
    
    //MARK:- Get Header Menu Data with MenuMaster API
    func callFuncToAddToFaveroite(TypeID:String,Id:String,mainID:String) {
        Loader.showLoader()
        var dict = Dictionary<String,Any>()
     
        var dict2 = Dictionary<String,Any>()
        dict2["main_id"] = mainID
        dict2["product_id"] = Id
        dict2["type_id"] = TypeID
        
        var arr = Array<Dictionary<String,Any>>()
        arr.append(dict2)
        dict["user_id"] = currentUser.id
        dict["product_data"] = arr
        dict["guru_id"] = "7"
        
        APIManager.apiCall(postData: dict as NSDictionary, url: Kadd_to_wishlist) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                self.isBookMarked = "1"
                self.bindDetailsToController()
            }else{
                
            }
        }
    }
    
    
}
