//
//  DashboardViewModel.swift
//  YeshuTV
//
//  Created by virendra kumar on 17/12/21.
//

import Foundation

class DashboardViewModel:NSObject{
    
    deinit {
        print("DashboardViewModel Dealloacated from Memory")
    }
    
    var menuList : [MenuListModel]?{
        didSet {
            self.bindMenuDataToController()
        }
    }
    
    var subMenuList : [SubMenuListModel]?{
        didSet {
            self.bindSubMenuDataToController()
        }
    }
    
    var bannerList: [BannerListModel]?{
        didSet{
            bindBannerDataToController()
        }
    }
    
    var contentList: [ContentListModel]?{
        didSet{
            bindContentListDataToController()
        }
    }
    
    var bindMenuDataToController : (() -> ()) = {}
    var bindSubMenuDataToController : (() -> ()) = {}
    var bindBannerDataToController : (() -> ()) = {}
    var bindContentListDataToController : (() -> ()) = {}
    
    override init() {
        super.init()
        callFuncToGetMenuMasterData()
        callFuncToGetSubMenuData()
        callFuncToGetBannerData()
        callFuncToGetDashBoardData()
    }
    
    //MARK:- Get Header Menu Data with MenuMaster API
    func callFuncToGetMenuMasterData() {
        Loader.showLoader()
        APIManager.apiCall(postData: [:], url: Kget_menu_master) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict!["data"] as Any
                if let nsdata = convertAnythingTOData(dict: dataArr) {
                    let jsonDecoder = JSONDecoder()
                    self.menuList = try? jsonDecoder.decode([MenuListModel].self, from: nsdata)
                    if self.menuList?.count != 0{
                        let hh = MenuListModel.init()
                        self.menuList?.insert(hh, at: 0)
                    }
                }
            }else{
                self.menuList = nil
            }
        }
    }
    
    
    //MARK:- Get Sub Menu List
    func callFuncToGetSubMenuData() {
        var dict = Dictionary<String,Any>()
        dict["type_id"] = "2"
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kget_menu_sub_category) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict!["data"] as Any
                if let nsdata = convertAnythingTOData(dict: dataArr) {
                    let jsonDecoder = JSONDecoder()
                    self.subMenuList = try? jsonDecoder.decode([SubMenuListModel].self, from: nsdata)
                }
            }else{
                self.subMenuList = nil
            }
        }
    }
    
    //MARK:- Get Banner List API
    func callFuncToGetBannerData() {
        var dict = Dictionary<String,Any>()
        dict["guru_id"] = "7"
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kbanner_list) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataArr = responseDict!["data"] as Any
                if let nsdata = convertAnythingTOData(dict: dataArr) {
                    let jsonDecoder = JSONDecoder()
                    self.bannerList = try? jsonDecoder.decode([BannerListModel].self, from: nsdata)
                }
            }else{
                self.bannerList = nil
            }
        }
    }
    
    
    //MARK:- Get Dashboard Data like video,audio,pdf List API
    func callFuncToGetDashBoardData() {
        var dict = Dictionary<String,Any>()
        dict["guru_id"] = "7"
        dict["user_id"] = currentUser.id
        
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kget_mobile_dashboard) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataDict = responseDict!["data"] as! Dictionary<String,Any>
                let content_list = dataDict["content_list"] as Any
                if let nsdata = convertAnythingTOData(dict: content_list) {
                    let jsonDecoder = JSONDecoder()
                    self.contentList = try? jsonDecoder.decode([ContentListModel].self, from: nsdata)
                }
            }else{
                self.contentList = nil
            }
        }
    }
    
    
    
    
    //MARK:- Get Dashboard with selected type Data like video,audio,pdf List API
    func callFuncToGetDashBoardData(typeId:String,Id:String) {
        var dict = Dictionary<String,Any>()
        dict["guru_id"] = "7"
        dict["user_id"] = currentUser.id
        dict["type_id"] = typeId
        dict["id"] = Id
        
        Loader.showLoader()
        APIManager.apiCall(postData: dict as NSDictionary, url: Kget_mobile_dashboard) { (status, responseDict, error, data) in
            Loader.hideLoader()
            if let _ = data ,(responseDict?["status"] as? Bool) == true,responseDict != nil{
                let dataDict = responseDict!["data"] as! Dictionary<String,Any>
                let content_list = dataDict["content_list"] as Any
                if let nsdata = convertAnythingTOData(dict: content_list) {
                    let jsonDecoder = JSONDecoder()
                    self.contentList = try? jsonDecoder.decode([ContentListModel].self, from: nsdata)
                }
            }else{
                self.contentList = nil
            }
        }
    }

    
}
