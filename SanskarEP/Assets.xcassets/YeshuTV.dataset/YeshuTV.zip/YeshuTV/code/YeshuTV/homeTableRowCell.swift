//
//  homeTableRowCell.swift
//  Mahua TV
//
//  Created by virendra kumar on 06/08/21.
//

import UIKit

class homeTableRowCell: UITableViewCell {

    @IBOutlet weak var homeCollectionView:UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
