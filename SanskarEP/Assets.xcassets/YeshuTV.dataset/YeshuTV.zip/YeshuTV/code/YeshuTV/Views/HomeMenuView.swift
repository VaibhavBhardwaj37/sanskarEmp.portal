//
//  HomeMenuView.swift
//  YeshuTV
//
//  Created by virendra kumar on 17/12/21.
//

import UIKit

//MARK:- FIRST VIEW OF HOME SCREEN FROM TOP
class HomeMenuView: UIView,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var categoryCollection:UICollectionView!
    var selectedIndex = IndexPath(row: 0, section: 0)
    var simpleClosure:(Int) -> () = {_ in }
    
    var menuList : [MenuListModel]? {
        didSet {
            self.categoryCollection.reloadData()
        }
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        
        categoryCollection.dataSource = self
        categoryCollection.delegate = self
        categoryCollection.collectionViewLayout.invalidateLayout()
        categoryCollection.reloadData()
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.menuList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CetegoryCell", for: indexPath) as! CetegoryCell
        
        
        cell.lbl_categoryName.textColor = .gray
        cell.lbl_categoryName.font = .systemFont(ofSize: 13, weight: .regular)
        cell.lbl_categoryName.text = self.menuList?[indexPath.row].menu_title.uppercased()
        cell.backgroundColor = appColorGrey
        cell.layer.cornerRadius = 4
        
        
        if indexPath == selectedIndex{
            
            cell.backgroundColor = appColor1
            cell.lbl_categoryName.textColor = .black
            cell.lbl_categoryName.font = .systemFont(ofSize: 13, weight: .bold)
            
        }
        cell.layoutIfNeeded()
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let label = UILabel(frame: CGRect.zero)
        label.text = self.menuList?[indexPath.row].menu_title
        label.sizeToFit()
       // return CGSize(width: label.frame.size.width+15, height: 32)
        return CGSize(width: (collectionView.frame.size.width-50)/4, height: 32)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if selectedIndex.row == indexPath.row{
            return
        }
        
        selectedIndex = indexPath
        simpleClosure(indexPath.row)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
    }
    
}


class CetegoryCell: UICollectionViewCell{
    @IBOutlet weak var lbl_categoryName:UILabel!
    
}



