//
//  gredientView.swift
//  Poppn
//
//  Created by viru on 09/04/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable
class gredientView: UIView {
    
    @IBInspectable var firstColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var secondColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            updateView()
        }
    }
 
    
    @IBInspectable var isHorizontal: Bool = true {
        didSet {
            updateView()
        }
    }
    @IBInspectable var isTopCorner: Bool = false {
        didSet {
            updateView()
        }
    }
    @IBInspectable var isBottomCorner: Bool = false {
        didSet {
            updateView()
        }
    }
    @IBInspectable var borderWidth: Double {
        get {
            return Double(self.layer.borderWidth)
        }
        set {
            self.layer.borderWidth = CGFloat(newValue)
        }
    }
    @IBInspectable var borderColor: UIColor? {
        get {
            return UIColor(cgColor: self.layer.borderColor!)
        }
        set {
            self.layer.borderColor = newValue?.cgColor
        }
    }
    
    @IBInspectable var addShadow:Bool = false{
        
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var shadowColor:UIColor = UIColor.clear{
        didSet {
            updateShadowColor()
        }
    }
    
    @IBInspectable var shadowOpacity: Float = 0.3 {
        didSet {
            layer.shadowOpacity = shadowOpacity
        }
    }
    
    @IBInspectable var shadowOffset: Float = 5 {
        didSet {
            layer.shadowRadius = CGFloat(shadowOffset)
            layer.shadowOffset = CGSize(width: 0, height: Int(shadowOffset))
        }
    }
    
    func updateShadowColor(){
        self.layer.shadowColor = shadowColor.cgColor
    }

    
    override class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    func updateView() {
        let layer = self.layer as! CAGradientLayer
        
        if isTopCorner{
            layer.cornerRadius = cornerRadius
            layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        }
        else if isBottomCorner{
            layer.cornerRadius = cornerRadius
            layer.maskedCorners = [.layerMinXMaxYCorner,.layerMaxXMaxYCorner]
        }
        else{
            layer.cornerRadius = cornerRadius
        }
        
        layer.colors = [firstColor, secondColor].map {$0.cgColor}
        if (isHorizontal) {
            layer.startPoint = CGPoint(x: 0, y: 0.5)
            layer.endPoint = CGPoint (x: 1, y: 0.5)
        }else {
            layer.startPoint = CGPoint(x: 0.5, y: 0)
            layer.endPoint = CGPoint (x: 0.5, y: 1)
            
        }
        
        
        if addShadow {
            layer.masksToBounds = false
            layer.shadowOpacity = shadowOpacity
            layer.shadowOffset = CGSize(width: 0, height: Int(shadowOffset))
            layer.shadowRadius = CGFloat(shadowOffset)
        }
        
    }
}

class customeView: UIView{
    
    @IBInspectable var cornerRadius: CGFloat = 0{
        didSet {
            updateView()
        }
    }
    
    override class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    func updateView() {
        let layer = self.layer as! CAGradientLayer
        layer.cornerRadius = cornerRadius
    }
}

class customeImageView: UIImageView {
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var borderColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }

    override class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    
    func updateView() {
        let layer = self.layer as! CAGradientLayer
        
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor.cgColor
        
    }
    
}




/**
 A beautiful and flexible textfield implementation with support for title label, error message and placeholder.
 */
@IBDesignable
open class TextFieldPlaceHolder: UITextField {
    
    /// A UIColor value that determines text color of the placeholder label
    @IBInspectable dynamic open var placeholderColor: UIColor = #colorLiteral(red: 0.503057301, green: 0.4454029202, blue: 0.5196571946, alpha: 1) {
        didSet {
            updatePlaceholder()
        }
    }
    /// A UIFont value that determines text color of the placeholder label
    @objc dynamic open var placeholderFont: UIFont? {
        didSet {
            updatePlaceholder()
        }
    }
    
    /// A UIColor value that determines the color used for the title label and line when text field is disabled
    @IBInspectable dynamic open var disabledColor: UIColor = UIColor(white: 0.88, alpha: 1.0) {
        didSet {
            updatePlaceholder()
        }
    }

    
    
    fileprivate func updatePlaceholder() {
        guard let placeholder = placeholder, let font = placeholderFont ?? font else {
            return
        }
        let color = isEnabled ? placeholderColor : disabledColor
        #if swift(>=4.2)
            attributedPlaceholder = NSAttributedString(
                string: placeholder,
                attributes: [
                    NSAttributedString.Key.foregroundColor: color, NSAttributedString.Key.font: font
                ]
            )
        #elseif swift(>=4.0)
            attributedPlaceholder = NSAttributedString(
                string: placeholder,
                attributes: [
                    NSAttributedStringKey.foregroundColor: color, NSAttributedStringKey.font: font
                ]
            )
        #else
            attributedPlaceholder = NSAttributedString(
                string: placeholder,
                attributes: [NSForegroundColorAttributeName: color, NSFontAttributeName: font]
            )
        #endif
    }
    
}



