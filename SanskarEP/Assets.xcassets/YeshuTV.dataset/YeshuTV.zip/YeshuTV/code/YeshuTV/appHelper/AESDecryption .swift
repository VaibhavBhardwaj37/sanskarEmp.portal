//
//  AESDecryption .swift
//  Etqan Academy
//
//  Created by virendra kumar on 22/03/21.
//  Copyright © 2021 mac. All rights reserved.
//

import Foundation
import CryptoSwift


//MARK:- AES Decryption

struct AES {

    // MARK: - Value
    // MARK: Private
    private let key: Data
    private let iv: Data

    // MARK: - Initialzier
    init?(key: String, iv: String) {
        guard key.count == kCCKeySizeAES128 || key.count == kCCKeySizeAES256, let keyData = key.data(using: .utf8) else {
            debugPrint("Error: Failed to set a key.")
            return nil
        }
        guard iv.count == kCCBlockSizeAES128, let ivData = iv.data(using: .utf8) else {
            debugPrint("Error: Failed to set an initial vector.")
            return nil
        }
        self.key = keyData
        self.iv  = ivData
    }


    // MARK: - Function
    // MARK: Public
    func encrypt(string: String) -> Data? {
        return crypt(data: string.data(using: .utf8), option: CCOperation(kCCEncrypt))
    }
      func MYdecrypt(data: Data?) -> Data? {
            guard let decryptedData = crypt(data: data, option: CCOperation(kCCDecrypt)) else { return nil }
             return decryptedData
        }
    func decrypt(data: Data?) -> String? {
        guard let decryptedData = crypt(data: data, option: CCOperation(kCCDecrypt)) else { return nil }
         return String(bytes: decryptedData, encoding: .utf8)
    }

    
//    func MD5(_ string: String) -> String {
//        let context = UnsafeMutablePointer<CC_MD5_CTX>.allocate(capacity: 1)
//        var digest = Array<UInt8>(repeating:0, count:Int(CC_MD5_DIGEST_LENGTH))
//        CC_MD5_Init(context)
//        CC_MD5_Update(context, string, CC_LONG(string.lengthOfBytes(using: String.Encoding.utf8)))
//        CC_MD5_Final(&digest, context)
//       // context.deallocate(capacity: 1)
//        var hexString = ""
//        for byte in digest {
//            hexString += String(format:"%02x", byte)
//        }
//        return hexString
//    }
    

    func crypt(data: Data?, option: CCOperation) -> Data? {
        guard let data = data else { return nil }

        let cryptLength = data.count + kCCBlockSizeAES128
        var cryptData   = Data(count: cryptLength)

        let keyLength = key.count
        let options   = CCOptions(kCCOptionPKCS7Padding)

        var bytesLength = Int(0)

        let status = cryptData.withUnsafeMutableBytes { cryptBytes in
            data.withUnsafeBytes { dataBytes in
                iv.withUnsafeBytes { ivBytes in
                    key.withUnsafeBytes { keyBytes in
                    CCCrypt(option, CCAlgorithm(kCCAlgorithmAES), option, keyBytes.baseAddress, keyLength, ivBytes.baseAddress, dataBytes.baseAddress, data.count, cryptBytes.baseAddress, cryptLength, &bytesLength)
                    }
                }
            }
        }

        guard UInt32(status) == UInt32(kCCSuccess) else {
            debugPrint("Error: Failed to crypt data. Status \(status)")
            return nil
        }

        cryptData.removeSubrange(bytesLength..<cryptData.count)
        return cryptData
    }
    
    

    static func getAesKey(char:Character) -> Character{
    
    //  var aes = "!*@#)($^%1fgv&C="
        
        // 1621879810733165
        // !*@#)($^%1fgv&C=
        

        switch char {
        case "0":
            return "!"
        case "1":
            return "*"
        case "2":
            return "@"
        case "3":
            return "#"
        case "4":
            return ")"
        case "5":
            return "("
        case "6":
            return "$"
        case "7":
            return "^"
        case "8":
            return "%"
        case "9":
            return "1"
        default:
            return "\0"
        }
    }
    
    
   static func getVI(char:Character) -> Character{

    // var vi = "?\:><{}@#Vjekl/4"
    
    // ?\\:><{}@#Vjekl/4
    
    //  1621879810733165
    //  \}:\#@V#\?@>>\}{
    
        switch char {
        case "0":
            return "?"
        case "1":
            return "\\"
        case "2":
            return ":"
        case "3":
            return ">"
        case "4":
            return "<"
        case "5":
            return "{"
        case "6":
            return "}"
        case "7":
            return "@"
        case "8":
            return "#"
        case "9":
            return "V"
        default:
            return "\0"
        }
      
    }
   
}



