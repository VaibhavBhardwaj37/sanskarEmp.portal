//
//  CustomExtension.swift
//  Mahua TV
//
//  Created by virendra kumar on 18/08/21.
//

import Foundation
import UIKit
import SDWebImage

extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return nil }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return nil
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}


extension UIColor {
    static func random() -> UIColor {
        return UIColor(
            red:   .random(in: 0...1),
            green: .random(in: 0...1),
            blue:  .random(in: 0...1),
            alpha: 1.0
        )
    }
}

extension UIApplication {
    static var release: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String? ?? "x.x"
    }
    static var build: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String? ?? "x"
    }
    static var version: String {
        return "\(release).\(build)"
    }
}

extension CALayer{
    //width should be greater then height other it will be show as circle
    func Capsule(){
        self.cornerRadius = self.frame.height/2
    }
    func Circle(){
        self.cornerRadius = self.frame.height/2
        self.masksToBounds = true
    }
    func topCorner(){
        self.cornerRadius = 10.0
        self.maskedCorners = [.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
    func BottomCorner(){
        self.cornerRadius = 10.0
        self.maskedCorners = [.layerMinXMaxYCorner,.layerMaxXMaxYCorner]
    }
  
    func cornerView(value:CGFloat){
        self.masksToBounds = true
        self.cornerRadius = value
    }
 
}

extension UIView{
    
    func DashPatternBorder(){
        let yourViewBorder = CAShapeLayer()
        yourViewBorder.strokeColor = UIColor.lightGray.cgColor
        yourViewBorder.lineDashPattern = [10, 5]
        yourViewBorder.lineDashPhase = 4
        //yourViewBorder.lineCap = .round
        // yourViewBorder.lineJoin = .round
        yourViewBorder.frame = self.bounds
        yourViewBorder.fillColor = nil
        yourViewBorder.cornerRadius = 20.0
        yourViewBorder.path = UIBezierPath(rect:  self.bounds).cgPath
        self.layer.addSublayer(yourViewBorder)
        
    }
    

    
}


extension UIButton{
    func animationZoom() {
        UIView.animate(withDuration: 0.1, animations: {
            // let unlikedScale: CGFloat = 0.7
            let likedScale: CGFloat = 1.05
            self.transform = self.transform.scaledBy(x: likedScale, y: likedScale)
        }, completion: { _ in
            UIView.animate(withDuration: 0.1, animations: {
                self.transform = CGAffineTransform.identity
            })
        })
    }
}


extension UINavigationController {
  func popToViewController(ofClass: AnyClass, animated: Bool = true) {
    if let vc = viewControllers.last(where: { $0.isKind(of: ofClass) }) {
      popToViewController(vc, animated: animated)
    }
  }
}
extension UITableView {
    func setBackgroundIfNoData(message:String){
        if message != ""{
            self.backgroundView = nil
            let lbl = UILabel()
            lbl.numberOfLines = 0
            lbl.text = message
            lbl.frame = CGRect(x: 0, y: self.frame.size.height, width: self.frame.size.width, height: self.frame.size.height)
            lbl.textAlignment = .center
            lbl.textColor = .darkGray
            self.backgroundView = lbl
        }else{
            self.backgroundView = nil
        }
    }
}

extension UICollectionView {
    func setBackgroundIfNoData(message:String){
        if message != ""{
            self.backgroundView = nil
            let lbl = UILabel()
            lbl.numberOfLines = 0
            lbl.text = message
            lbl.frame = CGRect(x: 0, y: self.frame.size.height, width: self.frame.size.width, height: self.frame.size.height)
            lbl.textAlignment = .center
            lbl.textColor = .darkGray
            self.backgroundView = lbl
        }else{
            self.backgroundView = nil
        }
    }
}


extension UIViewController{
    
    func mainStoryBoard()-> UIStoryboard{
        let story = UIStoryboard.init(name: "Main", bundle: nil)
        return story
    }
    
    func HomeStoryBoard()-> UIStoryboard{
        let story = UIStoryboard.init(name: "Home", bundle: nil)
        return story
    }
    
    func MusicStoryBoard()-> UIStoryboard{
        let story = UIStoryboard.init(name: "Music", bundle: nil)
        return story
    }
    func SeriesStoryBoard()-> UIStoryboard{
        let story = UIStoryboard.init(name: "Series", bundle: nil)
        return story
    }
    func RShowStoryBoard()-> UIStoryboard{
        let story = UIStoryboard.init(name: "RShow", bundle: nil)
        return story
    }
    
    
}



extension Double {
    
    private var formatter: DateComponentsFormatter {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.minute, .second]
        formatter.unitsStyle = .positional
        formatter.zeroFormattingBehavior = .pad
        return formatter
    }
    
    func secondsToString() -> String {
        return formatter.string(from: self) ?? ""
    }
    
}

extension URL {
    var attributes: [FileAttributeKey : Any]? {
        do {
            return try FileManager.default.attributesOfItem(atPath: path)
        } catch let error as NSError {
            print("FileAttribute error: \(error)")
        }
        return nil
    }

    var fileSize: UInt64 {
        return attributes?[.size] as? UInt64 ?? UInt64(0)
    }
    

    var fileSizeString: String {
        return ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file)
    }

    var creationDate: Date? {
        return attributes?[.creationDate] as? Date
    }
}



class ImageStore: NSObject {
    static let imageCache = NSCache<NSString, UIImage>()
}

extension UIViewController {
    func GetImageWithURL(_ url: String?,completionHandler: @escaping (_ image: UIImage?) -> Void){
        //Use with sdwebimage if already have install
        let image4 = UIImageView()
        image4.sd_setImage(with: URL(string: url ?? "")) { (img, err, cache, url) in
            completionHandler(img)
        }
        
        //     DispatchQueue.global().async {
        //            guard let stringURL = url, let url = URL(string: stringURL) else {
        //                return
        //            }
        //            func setImage(image:UIImage?) {
        //                DispatchQueue.main.async {
        //                   completionHandler(image)
        //                }
        //            }
        //            let urlToString = url.absoluteString as NSString
        //            if let cachedImage = ImageStore.imageCache.object(forKey: urlToString) {
        //                setImage(image: cachedImage)
        //            } else if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
        //                DispatchQueue.main.async {
        //                    ImageStore.imageCache.setObject(image, forKey: urlToString)
        //                    setImage(image: image)
        //                }
        //            }else {
        //                setImage(image: nil)
        //            }
        //        }
        
    }
    
}


func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    #if DEBUG
    items.forEach {
        Swift.print($0, separator: separator, terminator: terminator)
    }
    #endif
}

func debugPrint(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    #if DEBUG
    items.forEach {
        Swift.debugPrint($0, separator: separator, terminator: terminator)
    }
    #endif
}

func convertAnythingTOData(dict:Any) -> Data?{
    
    do {
        let jsonData = try JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted)
        return jsonData
    } catch {
        print(error.localizedDescription)
    }
    return nil
}


extension String {
    func ValidateEmail() -> Bool {
        print("validate emilId: \(self)")
        let emailRegEx = "^(?:(?:(?:(?: )(?:(?:(?:\\t| )\\r\\n)?(?:\\t| )+))+(?: ))|(?: )+)?(?:(?:(?:[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+(?:\\.[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+)*)|(?:\"(?:(?:(?:(?: )(?:(?:[!#-Z^-~]|\\[|\\])|(?:\\\\(?:\\t|[ -~]))))+(?: ))|(?: )+)\"))(?:@)(?:(?:(?:[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)(?:\\.[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)*)|(?:\\[(?:(?:(?:(?:(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))\\.){3}(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))))|(?:(?:(?: )[!-Z^-~])*(?: ))|(?:[Vv][0-9A-Fa-f]+\\.[-A-Za-z0-9._~!$&'()*+,;=:]+))\\])))(?:(?:(?:(?: )(?:(?:(?:\\t| )\\r\\n)?(?:\\t| )+))+(?: ))|(?: )+)?$"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: self)
        return result
    }
}

extension String {
    func isNumeric() -> Bool{
        if Int(self) == nil{
            return false
        }else{
            return true
        }
    }
}
