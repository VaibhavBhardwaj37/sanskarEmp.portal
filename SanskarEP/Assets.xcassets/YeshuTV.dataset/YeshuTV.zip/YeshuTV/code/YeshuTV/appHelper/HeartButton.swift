//
//  HeartButton.swift
//  Animations Demo
//
//  Created by Alejandrina Patrón López on 6/11/20.
//  Copyright © 2020 Alejandrina Patrón López. All rights reserved.
//

import UIKit

class HeartButton: UIButton {
  var isLiked = false

  private let unlikedImage = UIImage(named: "favorite")
  private let likedImage = UIImage(named: "heart_filled")
  
  private let unlikedScale: CGFloat = 0.7
  private let likedScale: CGFloat = 1.3

  public func flipLikedState() {
    animate()
  }

  private func animate() {
    UIView.animate(withDuration: 0.1, animations: {
      let newImage = self.isLiked ? self.likedImage : self.unlikedImage
      let newScale = self.isLiked ? self.likedScale : self.unlikedScale
      self.transform = self.transform.scaledBy(x: newScale, y: newScale)
      self.setImage(newImage, for: .normal)
    }, completion: { _ in
      UIView.animate(withDuration: 0.1, animations: {
        self.transform = CGAffineTransform.identity
      })
    })
  }
}



