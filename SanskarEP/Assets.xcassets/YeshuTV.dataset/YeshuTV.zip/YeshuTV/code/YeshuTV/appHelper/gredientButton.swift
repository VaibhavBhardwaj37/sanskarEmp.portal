//
//  gredientButton.swift
//  Poppn
//
//  Created by mac on 10/04/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable
class gredientButton: UIButton {
    
    @IBInspectable var firstColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var backGroundColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }
    
    
    @IBInspectable var secondColor: UIColor = UIColor.clear {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var isHorizontal: Bool = true {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var addShadow:Bool = false{
        
        didSet {
            updateView()
        }
    }
    @IBInspectable var shadowColor:UIColor = UIColor.clear{
        didSet {
            updateShadowColor()
        }
    }
    
    @IBInspectable var isGredientOn:Bool = true{
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var shadowOpacity: Float = 0.3 {
        didSet {
            layer.shadowOpacity = shadowOpacity
        }
    }
    
    @IBInspectable var shadowOffset: Float = 5 {
        didSet {
            layer.shadowRadius = CGFloat(shadowOffset)
            layer.shadowOffset = CGSize(width: 0, height: Int(shadowOffset))
        }
    }
    
    
    override class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    
    func updateShadowColor(){
        self.layer.shadowColor = shadowColor.cgColor
    }
    
    func updateView() {
        let layer = self.layer as! CAGradientLayer
        
        layer.cornerRadius = cornerRadius
       
        if isGredientOn{
            layer.colors = [firstColor, secondColor].map {$0.cgColor}
            if (isHorizontal) {
                layer.startPoint = CGPoint(x: 0, y: 0.5)
                layer.endPoint = CGPoint (x: 1, y: 0.5)
            } else {
                layer.startPoint = CGPoint(x: 0.5, y: 0)
                layer.endPoint = CGPoint (x: 0.5, y: 1)
            }
            self.backgroundColor = .clear
        }else{
            layer.colors = [UIColor.clear, UIColor.clear].map {$0.cgColor}
            if (isHorizontal) {
                layer.startPoint = CGPoint(x: 0, y: 0.5)
                layer.endPoint = CGPoint (x: 1, y: 0.5)
            } else {
                layer.startPoint = CGPoint(x: 0.5, y: 0)
                layer.endPoint = CGPoint (x: 0.5, y: 1)
            }
            self.backgroundColor = backGroundColor
        }
        
        

        
        if addShadow {
            layer.masksToBounds = false
            layer.shadowOpacity = shadowOpacity
            layer.shadowOffset = CGSize(width: 0, height: Int(shadowOffset))
            layer.shadowRadius = CGFloat(shadowOffset)
        }
        
    }
    
    override func awakeFromNib() {
        
    }

    
}
