//
//  userModel.swift
//  Mahua TV

//  Created by virendra kumar on 28/07/21.

import Foundation
import UIKit
import CoreTelephony
struct dataContent{
    static var isAudio : String{
        return "4"
    }
    static var isWebSeries : String{
        return "2"
    }
}

struct currentUser{
    
    static var id : String{
        return UserDefaults.standard.value(forKey: "id") as? String ?? ""
    }
    
    static var name : String{
        return UserDefaults.standard.value(forKey: "name") as? String ?? ""
    }
    static var email : String{
        return UserDefaults.standard.value(forKey: "email") as? String ?? ""
    }
    
    static var mobile : String{
        return UserDefaults.standard.value(forKey: "mobile") as? String ?? ""
    }
    
    static var profile_picture : String{
        return UserDefaults.standard.value(forKey: "profile_picture") as? String ?? ""
    }
    
    static var gender : String{
        return UserDefaults.standard.value(forKey: "gender") as? String ?? ""
    }
    static var dob : String{
        return UserDefaults.standard.value(forKey: "dob") as? String ?? ""
    }
    
    static var address : String{
        return UserDefaults.standard.value(forKey: "address") as? String ?? ""
    }
    
    static var video_permission : String{
        return UserDefaults.standard.value(forKey: "video_permission") as? String ?? ""
    }
    
    static var jwt : String{
        return UserDefaults.standard.value(forKey: "jwt") as? String ?? ""
    }
    
    static var device_type : String{
        return UserDefaults.standard.value(forKey: "device_type") as? String ?? "3"
    }
    
    static var DeviceToken : String{
        return UserDefaults.standard.value(forKey: "DeviceToken") as? String ?? "abcxyz"
    }
    
    static var DeviceId:String{
        return UIDevice().identifierForVendor?.uuidString ?? ""
    }
    static var deviceModel:String{
        return UIDevice().model
    }
    // MARK:- Country Code and Phone code are same
    static var countryCode:String{
        
        let networkInfo: CTTelephonyNetworkInfo = CTTelephonyNetworkInfo()
        let ar = networkInfo.subscriberCellularProvider
        if ar != nil {
            if  let mcc = ar?.mobileCountryCode {
                return mcc
            }else{
                return "+91"
            }
        }
        return "+91"
    }
    
    static var language : String{
        return UserDefaults.standard.value(forKey: "language") as? String ?? ""
    }
    
    static var viewing_mode : String{
        return UserDefaults.standard.value(forKey: "viewing_mode") as? String ?? ""
    }
    
    
    static var App_version : String{
        return UserDefaults.standard.value(forKey: "App_version") as? String ?? UIApplication.release
    }
    
    static func saveData(Login_Data: NSDictionary) {
        
        let data = Login_Data.dictValue("data")
        let user_data = data.dictValue("user_data")
        
        UserDefaults.standard.setValue(data.validatedValue("jwt"), forKey: "jwt")
        
        UserDefaults.standard.setValue(user_data.validatedValue("id"), forKey: "id")
        UserDefaults.standard.setValue(user_data.validatedValue("name"), forKey: "name")
        UserDefaults.standard.setValue(user_data.validatedValue("mobile"), forKey: "mobile")
        UserDefaults.standard.setValue(user_data.validatedValue("profile_picture"), forKey: "profile_picture")
        UserDefaults.standard.setValue(user_data.validatedValue("email"), forKey: "email")
        
    }
    
    static func saveValue(value:String,key:String) {
        UserDefaults.standard.setValue(value, forKey: key)
    }
    
    static func removeData() {
        UserDefaults.standard.removeObject(forKey: "id")
    }
}


//MARK:- DICTIONARY VALIDATION
extension Dictionary {
    
    func validatedValue (_ key:Key) -> String{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                // if key not exist or key contain NSNull
                return ""
            }
            else if ((object as? String == "null") || (object as? String == "<null>") || (object as? String == "(null)") || (object as? String == "nil") || (object as? String == "Nil")) {
                //logInfo("null string")
                return ""
            }else{
                return "\(object)"
            }
        }else{
            return ""
        }
    }
    
    func dictValue(_ key:Key) -> Dictionary<String,Any>{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                return [:]
            }
            else if object.count == 0{
                return [:]
            }else{
                return object as? Dictionary<String,Any> ?? [:]
            }
        }else{
            return [:]
        }
    }
    
    func ArrayDict (_ key:Key) -> Array<Dictionary<String,Any>>{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                // if key not exist or key contain NSNull
                return []
            }
            else if object.count == 0{
                //logInfo("null string")
                return []
            }else{
                return object as? Array<Dictionary<String,Any>> ?? []
            }
        }else{
            return []
        }
    }
}


extension NSDictionary{
    func validatedValue (_ key:Key) -> String{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                // if key not exist or key contain NSNull
                return ""
            }
            else if ((object as? String == "null") || (object as? String == "<null>") || (object as? String == "(null)") || (object as? String == "nil") || (object as? String == "Nil")) {
                //logInfo("null string")
                return ""
            }else{
                return "\(object)"
            }
        }else{
            return ""
        }
    }
    
    
    func dictValue(_ key:Key) -> Dictionary<String,Any>{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                return [:]
            }
            else if object.count == 0{
                return [:]
            }else{
                return object as? Dictionary<String,Any> ?? [:]
            }
        }else{
            return [:]
        }
    }
    
    
    
    func ArrayofDict (_ key:Key) -> Array<Dictionary<String,Any>>{
        if let object = self[key] as? AnyObject{
            if object is NSNull{
                // if key not exist or key contain NSNull
                return []
            }
            else if object.count == 0{
                //logInfo("null string")
                return []
            }else{
                return object as? Array<Dictionary<String,Any>> ?? []
            }
        }else{
            return []
        }
    }
    
}
