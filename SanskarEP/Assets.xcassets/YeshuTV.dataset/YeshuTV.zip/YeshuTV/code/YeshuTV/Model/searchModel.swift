//
//  searchModel.swift
//  Mahua TV
//
//  Created by virendra kumar on 22/09/21.
//

import Foundation

struct searchModel: Codable {
    let thumbnailURL: String?
    let id, typeID, title, guruID: String?
    let subCategory: String?
    let type: String?
    let datumDescription: String?
    let bannerURL: String?
    let url: String?

    enum CodingKeys: String, CodingKey {
        case thumbnailURL = "thumbnail_url"
        case id
        case typeID = "type_id"
        case title
        case guruID = "guru_id"
        case subCategory = "sub_category"
        case type
        case datumDescription = "description"
        case bannerURL = "banner_url"
        case url
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        thumbnailURL = try values.decodeIfPresent(String.self, forKey: .thumbnailURL)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        typeID = try values.decodeIfPresent(String.self, forKey: .typeID)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        guruID = try values.decodeIfPresent(String.self, forKey: .guruID)
        
        subCategory = try values.decodeIfPresent(String.self, forKey: .subCategory)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        datumDescription = try values.decodeIfPresent(String.self, forKey: .datumDescription)
        bannerURL = try values.decodeIfPresent(String.self, forKey: .bannerURL)
        url = try values.decodeIfPresent(String.self, forKey: .url)
    }
    
}
