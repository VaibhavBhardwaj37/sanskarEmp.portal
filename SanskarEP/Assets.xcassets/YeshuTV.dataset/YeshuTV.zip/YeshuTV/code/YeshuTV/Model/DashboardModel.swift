//
//  DashboardModel.swift
//  YeshuTV
//
//  Created by virendra kumar on 23/12/21.
//

import Foundation
import AVKit


// MARK: - ContentList
struct ContentListModel: Codable {
    let id, typeID, categoryName: String?
    let listing: [ListingModel]?
    let catID:String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case typeID = "type_id"
        case catID = "cat_id"
        case categoryName = "category_name"
        case listing
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        typeID = try values.decodeIfPresent(String.self, forKey: .typeID)
        catID = try values.decodeIfPresent(String.self, forKey: .catID)
        categoryName = try values.decodeIfPresent(String.self, forKey: .categoryName)
        listing = try values.decodeIfPresent([ListingModel].self, forKey: .listing)
    }
}

// MARK: - Listing
struct ListingModel: Codable {
    let id, typeID: String?
    let type: String?
    let title: String?
    let guruName: String?
    let listingDescription: String?
    let bannerURL: String?
    let thumbnailURL: String?
    let subCategory: String?
    let url: String?
    let guruID, name, creationTime, uploadedBy: String?
    let status: String?
    var timeingText = ""
    
    enum CodingKeys: String, CodingKey {
        case id
        case typeID = "type_id"
        case type, title
        case guruName = "guru_name"
        case listingDescription = "description"
        case bannerURL = "banner_url"
        case thumbnailURL = "thumbnail_url"
        case subCategory = "sub_category"
        case url
        case guruID = "guru_id"
        case name
        case creationTime = "creation_time"
        case uploadedBy = "uploaded_by"
        case status
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        typeID = try values.decodeIfPresent(String.self, forKey: .typeID)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        guruName = try values.decodeIfPresent(String.self, forKey: .guruName)
        listingDescription = try values.decodeIfPresent(String.self, forKey: .listingDescription)
        bannerURL = try values.decodeIfPresent(String.self, forKey: .bannerURL)
        thumbnailURL = try values.decodeIfPresent(String.self, forKey: .thumbnailURL)
        subCategory = try values.decodeIfPresent(String.self, forKey: .subCategory)
        url = try values.decodeIfPresent(String.self, forKey: .url)
        guruID = try values.decodeIfPresent(String.self, forKey: .guruID)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        creationTime = try values.decodeIfPresent(String.self, forKey: .creationTime)
        uploadedBy = try values.decodeIfPresent(String.self, forKey: .uploadedBy)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        
        
        if typeID == "1"{
            if let videoURL = URL(string: url ?? ""){
                let player = AVPlayer(url: videoURL)
                let item = AVPlayerItem(url: videoURL)
                player.replaceCurrentItem(with: item)
                if let duration = player.currentItem?.asset.duration{
                    self.timeingText = self.convert(second: duration.seconds)
                }
            }
        }
    }
    
    private func convert(second: Double) -> String {
        let component =  Date.dateComponentFrom(second: second)
        if let hour = component.hour ,
           let min = component.minute ,
           let sec = component.second {
            let fix =  hour > 0 ? NSString(format: "%02d:", hour) : ""
            return NSString(format: "%@%02d:%02d", fix,min,sec) as String
        } else {
            return "-:-"
        }
    }
    
    
}

