//
//  MenuModel.swift
//  YeshuTV
//
//  Created by virendra kumar on 17/12/21.
//


import Foundation
//MARK:-  Menu master of Home Screen
struct MenuListModel: Codable {
    let id, type_id, menu_title: String

    enum CodingKeys: String, CodingKey {
        case id
        case type_id
        case menu_title
    }
    init() {
        self.id = ""
        self.type_id = ""
        self.menu_title = "  All   "
    }
}

//MARK:- Sub Menu of Home Screen
struct SubMenuListModel: Codable {
    let id, type_id, category_name: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case type_id
        case category_name
    }
}


// MARK: - BannerListModel At Home Screen
struct BannerListModel: Codable {
    let title: String?
    let imageURL: String?
    let datumDescription, parentID, state: String?

    enum CodingKeys: String, CodingKey {
        case title
        case imageURL = "image_url"
        case datumDescription = "description"
        case parentID = "parent_id"
        case state
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        imageURL = try values.decodeIfPresent(String.self, forKey: .imageURL)
        datumDescription = try values.decodeIfPresent(String.self, forKey: .datumDescription)
        parentID = try values.decodeIfPresent(String.self, forKey: .parentID)
        state = try values.decodeIfPresent(String.self, forKey: .state)
    }
}
