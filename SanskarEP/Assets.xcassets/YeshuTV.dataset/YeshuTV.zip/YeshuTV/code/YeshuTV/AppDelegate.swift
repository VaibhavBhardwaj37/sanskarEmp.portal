//
//  AppDelegate.swift
//  YeshuTV
//
//  Created by virendra kumar on 15/12/21.
//

import UIKit


@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    static private(set) var shared: AppDelegate?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        Thread.sleep(forTimeInterval: 1.0)
        AppDelegate.shared = self
        
        if #available(iOS 13.0, *) {
           
        } else {
            appFlow()
        }
       
        return true
    }

    // MARK: UISceneSession Lifecycle
    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }

    func appFlow(){
        if currentUser.id != ""{
            let story = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = story.instantiateViewController(withIdentifier: "MyTabBarVC") as! MyTabBarVC
            let navi = UINavigationController.init(rootViewController: vc)
            navi.navigationBar.isHidden = true
            AppDelegate.shared?.window?.rootViewController = navi
            AppDelegate.shared?.window?.makeKeyAndVisible()
        }else{
            
            let story = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = story.instantiateViewController(withIdentifier: "OnBoardingVC") as! OnBoardingVC
            let navi = UINavigationController.init(rootViewController: vc)
            navi.navigationBar.isHidden = true
           
            AppDelegate.shared?.window?.rootViewController = navi
            AppDelegate.shared?.window?.makeKeyAndVisible()
            
            
        }
    }

}

